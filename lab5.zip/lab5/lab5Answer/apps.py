from django.apps import AppConfig


class Lab5AnswerConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "lab5Answer"
