from django.http import HttpResponse
from django.shortcuts import render

def home(request):
    return render(request,"helloworld.html",{'Message':"Hello World!"})
